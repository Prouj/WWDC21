//#-hidden-code
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    
    @State var animation = false
    @State var mensagex: CGFloat = 0
    @State var mensagey: CGFloat = 0
    @State var mensage2x: CGFloat = 191
    @State var mensage2y: CGFloat = 300
    @State var setaOpacity: Double = 0
    @State var setaOpacity2: Double = 0
    @State var setaOpacity3: Double = 0
    @State var setaOpacity4: Double = 0

    func animete() {
        withAnimation(.linear(duration: 3)){
            mensagex = 191
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            withAnimation(.linear(duration: 3)){
                mensagey = 300

            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
            withAnimation(.linear(duration: 3)){
                mensagey = 670

            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
            withAnimation(.linear(duration: 3)){
                mensagex = -20

            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 12) {
            withAnimation(.linear(duration: 3)){
                mensagex = 191
                setaOpacity4 = 1
            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 15) {
            withAnimation(.linear(duration: 3)){
                mensagey = 300
                setaOpacity3 = 1

            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 18) {
            withAnimation(.linear(duration: 3)){
                mensagey = 0
                setaOpacity2 = 1

            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 21) {
            withAnimation(.linear(duration: 3)){
                mensagex = 0
                setaOpacity = 1
            }
        }

    }
    
    var body: some View {
        VStack{
            ZStack{
                HStack{
                    Image(uiImage: UIImage(named: "User.png")!)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 180, height: 130)
                        .padding(.leading, 10)
                        .padding(.top, 60)
                        .onTapGesture {
                            animation = true
                        }
                    
                    VStack {
                        Image(uiImage: UIImage(named: "setaL.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 145, height: 21)
                            .offset(x: 0, y: -5)
                            
                        
                        Image(uiImage: UIImage(named: "mensage.png")!)
                        .resizable()
                        .frame(width: 60, height: 35)
                        .offset(x: mensagex ,y: mensagey)
//                        .onAppear { animation = true }
                        .onChange(of: animation, perform: { _ in animete() })
                        
                        Image(uiImage: UIImage(named: "setaR.png")!)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 145, height: 21)
                        .offset(x: 0, y: 5)
                        .opacity(setaOpacity)
                        
                        
                    }.padding(.horizontal, 10)
                    
                    VStack {
                        
                        Image(uiImage: UIImage(named: "view.png")!)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 200, height: 150)
                        .padding(.top, 650)
                        
                        
                        HStack {
                            
                            Image(uiImage: UIImage(named: "setaCima.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 21, height: 145)
                            .offset(x: -30, y: 0)
                            .opacity(setaOpacity2)
                            
                            Image(uiImage: UIImage(named: "setaBaixo.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 21, height: 145)
                            .offset(x: 30, y: 0)
                            
                            
                            
                        }.padding(.vertical, 10)
                        
                        Image(uiImage: UIImage(named: "controller.png")!)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 200, height: 150)
                        
                        HStack {
                            
                            Image(uiImage: UIImage(named: "setaCima.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 21, height: 145)
                            .offset(x: -30, y: 0)
                            .opacity(setaOpacity3)
                            
                            Image(uiImage: UIImage(named: "setaBaixo.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 21, height: 145)
                            .offset(x: 30, y: 0)
                            
                            
                            
                        }.padding(.vertical, 10)
                        
                        Image(uiImage: UIImage(named: "model.png")!)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 200, height: 150)
                    }
                }
                
                HStack {
                    Image(uiImage: UIImage(named: "data.png")!)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 100, height: 50)
                        .padding(.leading, 10)
                        .padding(.top, 60)
                    
                    VStack {
                        Image(uiImage: UIImage(named: "setaL.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 145, height: 21)
                            .offset(x: 0, y: -5)
                            .opacity(setaOpacity4)
                        
                        Image(uiImage: UIImage(named: "setaR.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 145, height: 21)
                            .offset(x: 0, y: 55)
                       
                        
                        
                    }.padding(.horizontal, 10)
                }.padding(.top, 1280)
                .padding(.leading, -130)
                
            }.padding(.bottom, 600)
            
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}


PlaygroundPage.current.setLiveView(ContentView().background(Color.white))
//#-end-hidden-code
/*:
 After going through View, Controller and Model, we see that MVC is a way of dividing the code that forms an application, for example, to separate things that form parts closer to the user and more distant things, and many times we don't even know that exists, like a database.

 By clicking on Run and then on User, you will be able to see the complete flow of MVC, from the request made by the user to the return of the information he requested.

 With that we conclude our presentation on MVC, I hope you can have understood it in the best way. Thank you very much 🙃😁🙃
 
*/

