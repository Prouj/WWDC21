//#-hidden-code
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    
    @State var animation = false
    @State var mensagex: CGFloat = -40
    @State var mensagey: CGFloat = 0
    @State var setaOpacity: Double = 0
    @State var setaOpacity1: Double = 0
    @State var setaOpacity2: Double = 0
    @State var setaOpacity3: Double = 0
    @State var controllerOpacity: Double = 0
    @State var mensageOpacity: Double = 0
    @State var userOpacity: Double = 0
 


    func animete() {
        withAnimation(.linear(duration: 3)){
            userOpacity = 1
            mensageOpacity = 1
            mensagex = 191
            setaOpacity2 = 1
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            withAnimation(.linear(duration: 3)){
                mensagey = 300
                setaOpacity3 = 1
                controllerOpacity = 1

            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
            withAnimation(.linear(duration: 3)){
                mensagey = 0
                setaOpacity1 = 1

            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
            withAnimation(.linear(duration: 3)){
                mensagex = 0
                setaOpacity = 1
            
            }
        }
    }
    
    var body: some View {
        VStack{
            ZStack{
                HStack{
                    Image(uiImage: UIImage(named: "User.png")!)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 180, height: 130)
                        .padding(.leading, 10)
                        .padding(.top, 60)
                        .opacity(userOpacity)
                    
                    VStack {
                        Image(uiImage: UIImage(named: "setaL.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 145, height: 21)
                            .offset(x: 0, y: -5)
                            .opacity(setaOpacity2)
                            
                        
                        Image(uiImage: UIImage(named: "mensage.png")!)
                        .resizable()
                        .frame(width: 60, height: 35)
                        .offset(x: mensagex ,y: mensagey)
                        .opacity(userOpacity)
                        .onChange(of: animation, perform: { _ in animete() })
                        
                        Image(uiImage: UIImage(named: "setaR.png")!)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 145, height: 21)
                        .offset(x: 0, y: 5)
                        .opacity(setaOpacity)
                        
                        
                    }.padding(.horizontal, 10)
                    
                    VStack {
                        
                        Image(uiImage: UIImage(named: "view.png")!)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 200, height: 150)
                        .padding(.top, 310)
                        .onTapGesture { animation = true }
                        
                        HStack {
                            
                            Image(uiImage: UIImage(named: "setaCima.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 21, height: 145)
                            .offset(x: -30, y: 0)
                            .opacity(setaOpacity1)
                            
                            Image(uiImage: UIImage(named: "setaBaixo.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 21, height: 145)
                            .offset(x: 30, y: 0)
                            .opacity(setaOpacity3)
                            
                            
                            
                        }.padding(.vertical, 10)
                        
                        Image(uiImage: UIImage(named: "controller.png")!)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 200, height: 150)
                        .opacity(controllerOpacity)
                    }
                }
            }.padding(.bottom, 200)
            
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}


PlaygroundPage.current.setLiveView(ContentView().background(Color.white))
//#-end-hidden-code
/*:
 The View is where the codes that make up the items on the screen you see are located, such as the pink folder you will see when you click on Run, features such as:

- Size
- Form
- Color
 
 All of this is defined in our View. By clicking on it, you will be able to view the interactions that View has in the MVC.
 
 In the flow you can see that you are the user and the View receives your touch on something from it, based on what you did, it tells the controller what you touched and then receives the response from the Controller, which she will show you.
*/

