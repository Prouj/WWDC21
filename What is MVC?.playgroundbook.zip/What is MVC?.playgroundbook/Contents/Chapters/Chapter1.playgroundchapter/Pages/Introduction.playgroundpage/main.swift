//#-hidden-code
import SwiftUI
import PlaygroundSupport
struct ContentView: View {
    
    var body: some View {
        ZStack{
            Image(uiImage: UIImage(named: "MVC?2.png")!)
                .resizable()
                .scaledToFill()
                .padding(.horizontal,20)
                .padding(.vertical,20)
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.width)

                
        }.frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.width)
    }
}

PlaygroundPage.current.setLiveView(ContentView().background(Color.white))
//#-end-hidden-code
/*:
 The MVC or Model View and Controller, is a software architecture, it separates the code that forms an application, in three files, the View, the Model and the Controller. This pattern was created in the 1980s at Xerox Parc, by Trygve Reenskaug, who started in 1979 what would become the birth of MVC architecture.
 */

