//#-hidden-code
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    
    @State var animation = false
    @State var mensagex: CGFloat = 0
    @State var mensagey: CGFloat = 50
    @State var setaOpacity: Double = 0
    @State var setaOpacity2: Double = 0
    @State var setaOpacity3: Double = 0
    @State var setaOpacity4: Double = 0
    @State var controllerOpacity: Double = 0
    @State var dataOpacity: Double = 0
    @State var mensageOpacity: Double = 0

    func animete() {
        withAnimation(.linear(duration: 3)){
            controllerOpacity = 1
            mensageOpacity = 1
            setaOpacity3 = 1
            mensagey = 340
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            withAnimation(.linear(duration: 3)){
                setaOpacity4 = 1
                dataOpacity = 1
                mensagex = -250
            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
            withAnimation(.linear(duration: 3)){
                mensagex = 0
                setaOpacity2 = 1

            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
            withAnimation(.linear(duration: 3)){
                mensagey = 50
                setaOpacity = 1
            }
        }

    }
    
    var body: some View {
        VStack{
            ZStack{
                HStack{
                    VStack {
                        
                        ZStack {
                            
                            Image(uiImage: UIImage(named: "mensage.png")!)
                            .resizable()
                            .frame(width: 60, height: 35)
                            .offset(x: mensagex ,y: mensagey)
                            .opacity(mensageOpacity)
                            .onChange(of: animation, perform: { _ in animete() })
                            
                            Image(uiImage: UIImage(named: "controller.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 200, height: 150)
                            .opacity(controllerOpacity)
                        }
                        
                        HStack {
                            
                            Image(uiImage: UIImage(named: "setaCima.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 21, height: 145)
                            .offset(x: -30, y: 0)
                            .opacity(setaOpacity)
                            
                            Image(uiImage: UIImage(named: "setaBaixo.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 21, height: 145)
                            .offset(x: 30, y: 0)
                            .opacity(setaOpacity3)
                            
                            
                            
                        }.padding(.vertical, 10)
                        
                        Image(uiImage: UIImage(named: "model.png")!)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 200, height: 150)
                            .onTapGesture {
                                animation = true
                            }
                    }
                }
                
                HStack {
                    Image(uiImage: UIImage(named: "data.png")!)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 100, height: 50)
                        .padding(.leading, 10)
                        .padding(.top, 60)
                        .opacity(dataOpacity)
                    
                    VStack {
                        Image(uiImage: UIImage(named: "setaL.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 145, height: 21)
                            .offset(x: 0, y: -5)
                            .opacity(setaOpacity2)
                        
                        Image(uiImage: UIImage(named: "setaR.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 145, height: 21)
                            .offset(x: 0, y: 55)
                            .opacity(setaOpacity4)
                       
                        
                        
                    }.padding(.horizontal, 10)
                }.padding(.top, 300)
                .padding(.leading, -400)
                
            }.padding(.trailing, -350)
            
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}


PlaygroundPage.current.setLiveView(ContentView().background(Color.white))
//#-end-hidden-code
/*:
 The model is also known as Business Object Model, is the place where the business logic is located, such as functions of:

- Save information

- Find the information

- Determine the format of the information

 By clicking on Run and Model, you can view her flow in MVC, where she receives a request from the Controller, searches for an answer to that request in the DataBase, and returns information to the Controller.
*/


