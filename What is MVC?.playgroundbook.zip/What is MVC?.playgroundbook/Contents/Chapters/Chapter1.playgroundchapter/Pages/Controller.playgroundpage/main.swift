//#-hidden-code
import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    
    @State var animation = false
    @State var mensagex: CGFloat = 150
    @State var mensagey: CGFloat = 0
    @State var setaOpacity: Double = 0
    @State var setaOpacity2: Double = 0
    @State var setaOpacity3: Double = 0
    @State var setaOpacity4: Double = 0
    @State var viewOpacity: Double = 0
    @State var modelOpacity: Double = 0
    @State var mensageOpacity: Double = 0
    
    func animete() {
        withAnimation(.linear(duration: 3)){
            mensageOpacity = 1
            mensagey = 300
            viewOpacity = 1
            setaOpacity3 = 1

        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            withAnimation(.linear(duration: 3)){
                mensagey = 650
                modelOpacity = 1
                setaOpacity4 = 1

            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
            withAnimation(.linear(duration: 3)){
                mensagey = 300
                setaOpacity2 = 1

            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
            withAnimation(.linear(duration: 3)){
                mensagey = 0
                setaOpacity = 1
            }
        }

    }
    
    var body: some View {
        
        
        VStack{
            ZStack{
                HStack{
                    
                    VStack {
                        Image(uiImage: UIImage(named: "mensage.png")!)
                        .resizable()
                        .frame(width: 60, height: 35)
                        .offset(x: mensagex ,y: mensagey)
                        .onChange(of: animation, perform: { _ in animete() })
                        .opacity(mensageOpacity)
                        
                        
                    }.padding(.horizontal, 10)
                    
                    VStack {
                        
                        Image(uiImage: UIImage(named: "view.png")!)
                        .resizable()
                        .scaledToFill()
                        .opacity(viewOpacity)
                        .frame(width: 200, height: 150)
                        .padding(.top, 650)
                        
                        HStack {
                            
                            Image(uiImage: UIImage(named: "setaCima.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 21, height: 145)
                            .offset(x: -30, y: 0)
                            .opacity(setaOpacity)
                            
                            Image(uiImage: UIImage(named: "setaBaixo.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 21, height: 145)
                            .offset(x: 30, y: 0)
                            .opacity(setaOpacity3)
                            
                            
                            
                        }.padding(.vertical, 10)
                        
                        Image(uiImage: UIImage(named: "controller.png")!)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 200, height: 150)
                        .onTapGesture { animation = true}

                        HStack {
                            
                            Image(uiImage: UIImage(named: "setaCima.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 21, height: 145)
                            .offset(x: -30, y: 0)
                            .opacity(setaOpacity2)
                            
                            Image(uiImage: UIImage(named: "setaBaixo.png")!)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 21, height: 145)
                            .offset(x: 30, y: 0)
                            .opacity(setaOpacity4)
                            
                            
                            
                        }.padding(.vertical, 10)
                        
                        
                        Image(uiImage: UIImage(named: "model.png")!)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 200, height: 150)
                            .opacity(modelOpacity)
                    }
                }
            }.padding(.bottom, 600)
            
        }.frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}


PlaygroundPage.current.setLiveView(ContentView().background(Color.white))
//#-end-hidden-code
/*:
 The controller is the local where files of the configuration of the information of the screen stayed, for example, if the View has a search bar, the information that you writing and research, need be understood for someone and this someone is the Controller, so how it will be a Controller that will return the result of your search to a View, which will present on the screen for you.

 By clicking on Run and on the Controller, you can view her flow in the MVC, where she receives an order from View, understands what was requested, and forwards it to a Model, which will return information, which the Controller will send to View.
*/
